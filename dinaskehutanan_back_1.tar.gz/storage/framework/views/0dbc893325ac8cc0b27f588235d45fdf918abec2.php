<div class="widget-main">
    <?php echo Form::model($data,['url'=>['user/kawasan_hutan', $data->id],'method'=>'PATCH']); ?>

        <table class="table table-bordered">
            <tr>
                <td>Tahun</td>
                <td class="<?php if($errors->has('tahun')): ?> has-error <?php endif; ?>">
                    <?php echo Form::date('tahun',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('tahun')): ?>
                        <small class="red"> <?php echo e($errors->first('tahun')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Luas Wilayah Kabupaten/Kota</td>
                <td class="<?php if($errors->has('luas')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('luas',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('luas')): ?>
                        <small class="red"> <?php echo e($errors->first('luas')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th colspan="2">Luas Kawasan Hutan Berdasarkan SK Menhut No.44 Tahun 2005 (Ha)</th>
            </tr>
            <tr>
                <td>Hutan Suaka Alam</td>
                <td class="<?php if($errors->has('suaka_alam')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('suaka_alam',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('suaka_alam')): ?>
                        <small class="red"> <?php echo e($errors->first('suaka_alam')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Hutan Lindung</td>
                <td class="<?php if($errors->has('lindung')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('lindung',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('lindung')): ?>
                        <small class="red"> <?php echo e($errors->first('lindung')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Hutan Produksi Terbatas</td>
                <td class="<?php if($errors->has('produksi_terbatas')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('produksi_terbatas',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('produksi_terbatas')): ?>
                        <small class="red"> <?php echo e($errors->first('produksi_terbatas')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Hutan Produksi Tetap</td>
                <td class="<?php if($errors->has('produksi_tetap')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('produksi_tetap',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('produksi_tetap')): ?>
                        <small class="red"> <?php echo e($errors->first('produksi_tetap')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Hutan Produksi Yang Dapat Dikonservasi</td>
                <td class="<?php if($errors->has('produksi_konservasi')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('produksi_konservasi',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('produksi_konservasi')): ?>
                        <small class="red"> <?php echo e($errors->first('produksi_konservasi')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Jumlah Luas Kawasan Hutan</td>
                <td class="<?php if($errors->has('jumlah_luas')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('jumlah_luas',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('jumlah_luas')): ?>
                        <small class="red"> <?php echo e($errors->first('jumlah_luas')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td>Persentase Terhadap Luas Wilayah %</td>
                <td class="<?php if($errors->has('persentase')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('persentase',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('persentase')): ?>
                        <small class="red"> <?php echo e($errors->first('persentase')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <button type="submit" class="btn btn-primary btn-sm">
            <i class="fa fa-save"> </i>
            Updated
        </button>

    <?php echo Form::close(); ?>

</div>