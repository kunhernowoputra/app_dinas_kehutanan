<div class="widget-main widget-list">
    <?php if(count($data) > 0): ?>
        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th class="center">
                    <label class="pos-rel">
                        <input type="checkbox" class="ace" />
                        <span class="lbl"></span>
                    </label>
                </th>
                <th>Tahun</th>
                <th>Lahan Kering Primer</th>
                <th>Lahan Kering Sekunder</th>
                <th>Hutan Rawa Primer</th>
                <th>Hutan Rawa Sekunder</th>
                <th>Hutan Mangrove Primer</th>
                <th>Hutan Mangrove Sekunder</th>
                <th>Semak Belukar</th>
                <th>Semak Belukar Rawa</th>
                <th>Savana</th>
                <th>HTI</th>
                <th>Perkebunan</th>
                <th>Pertanian</th>
                <th width="8%"></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($data as $row): ?>
                <tr>
                    <td class="center">
                        <label class="pos-rel">
                            <input type="checkbox" class="ace" />
                            <span class="lbl"></span>
                        </label>
                    </td>
                    <td><?php echo $row->tahun; ?></td>
                    <td><?php echo $row->lahan_kering_primer; ?></td>
                    <td><?php echo $row->lahan_kering_sekunder; ?></td>
                    <td><?php echo $row->hutan_rawa_primer; ?></td>
                    <td><?php echo $row->hutan_rawa_sekunder; ?></td>
                    <td><?php echo $row->hutan_mangrove_primer; ?></td>
                    <td><?php echo $row->hutan_mangrove_sekunder; ?></td>
                    <td><?php echo $row->semak_belukar; ?></td>
                    <td><?php echo $row->semak_belukar_rawa; ?></td>
                    <td><?php echo $row->savana; ?></td>
                    <td><?php echo $row->hti; ?></td>
                    <td><?php echo $row->perkebunan; ?></td>
                    <td><?php echo $row->pertanian; ?></td>
                    <td class="text-center">

                        <?php echo Form::open(['url'=>['user/lahan_vegetasi',$row->id],'method'=>'DELETE']); ?>

                        <div class="btn-group" role="group">
                            <a href="<?php echo e(url('user/lahan_vegetasi/show',$row->id)); ?>" class="btn btn btn-default btn-minier">
                                <i class="icon fa fa-search"></i>
                            </a>
                            <a href="<?php echo e(url('user/lahan_vegetasi/edit',$row->id)); ?>" class="btn btn btn-warning btn-minier">
                                <i class="icon fa fa-pencil"></i>
                            </a>
                            <button type="submit" class="btn btn btn-danger btn-minier">
                                <i class="icon fa fa-trash"></i>
                            </button>
                        </div>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        data tidak ditemukan
    <?php endif; ?>
</div>