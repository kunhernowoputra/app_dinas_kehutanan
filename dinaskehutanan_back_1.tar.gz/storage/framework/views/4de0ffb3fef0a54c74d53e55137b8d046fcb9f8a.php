<div class="widget-main widget-insert" style="display: none;">
    <?php echo Form::open(['url'=>'user/lahan_vegetasi']); ?>

        <table class="table table-bordered">
            <tr>
                <td>Tahun</td>
                <td class="<?php if($errors->has('tahun')): ?> has-error <?php endif; ?>">
                    <?php echo Form::date('tahun',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('tahun')): ?>
                        <small class="red"> <?php echo e($errors->first('tahun')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th colspan="2">Hutan Lahan Kering</th>
            </tr>
            <tr>
                <td>Primer</td>
                <td class="<?php if($errors->has('lahan_kering_primer')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('lahan_kering_primer',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('lahan_kering_primer')): ?>
                        <small class="red"> <?php echo e($errors->first('lahan_kering_primer')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Sekunder</td>
                <td class="<?php if($errors->has('lahan_kering_sekunder')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('lahan_kering_sekunder',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('lahan_kering_sekunder')): ?>
                        <small class="red"> <?php echo e($errors->first('lahan_kering_sekunder')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th colspan="2">Hutan Rawa</th>
            </tr>
            <tr>
                <td>Primer</td>
                <td class="<?php if($errors->has('hutan_rawa_primer')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('hutan_rawa_primer',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('hutan_rawa_primer')): ?>
                        <small class="red"> <?php echo e($errors->first('hutan_rawa_primer')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Sekunder</td>
                <td class="<?php if($errors->has('hutan_rawa_sekunder')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('hutan_rawa_sekunder',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('hutan_rawa_sekunder')): ?>
                        <small class="red"> <?php echo e($errors->first('hutan_rawa_sekunder')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th colspan="2">Hutan Mangrove</th>
            </tr>
            <tr>
                <td>Primer</td>
                <td class="<?php if($errors->has('hutan_mangrove_primer')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('hutan_mangrove_primer',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('hutan_mangrove_primer')): ?>
                        <small class="red"> <?php echo e($errors->first('hutan_mangrove_primer')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Sekunder</td>
                <td class="<?php if($errors->has('hutan_mangrove_sekunder')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('hutan_mangrove_sekunder',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('hutan_mangrove_sekunder')): ?>
                        <small class="red"> <?php echo e($errors->first('hutan_mangrove_sekunder')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th colspan="2">Semak</th>
            </tr>
            <tr>
                <td>Belukar</td>
                <td class="<?php if($errors->has('semak_belukar')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('semak_belukar',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('semak_belukar')): ?>
                        <small class="red"> <?php echo e($errors->first('semak_belukar')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Belukar Rawa</td>
                <td class="<?php if($errors->has('semak_belukar_rawa')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('semak_belukar_rawa',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('semak_belukar_rawa')): ?>
                        <small class="red"> <?php echo e($errors->first('semak_belukar_rawa')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Savana</td>
                <td class="<?php if($errors->has('savana')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('savana',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('savana')): ?>
                        <small class="red"> <?php echo e($errors->first('savana')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>HTI</td>
                <td class="<?php if($errors->has('hti')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('hti',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('hti')): ?>
                        <small class="red"> <?php echo e($errors->first('hti')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Perkebunan</td>
                <td class="<?php if($errors->has('perkebunan')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('perkebunan',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('perkebunan')): ?>
                        <small class="red"> <?php echo e($errors->first('perkebunan')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Pertanian</td>
                <td class="<?php if($errors->has('pertanian')): ?> has-error <?php endif; ?>">
                    <?php echo Form::text('pertanian',null,['class'=>'form-control']); ?>

                    <?php if($errors->has('pertanian')): ?>
                        <small class="red"> <?php echo e($errors->first('pertanian')); ?> </small>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <button type="submit" class="btn btn-primary btn-sm">
            <i class="fa fa-save"> </i>
            Simpan
        </button>
    <?php echo Form::close(); ?>

</div>