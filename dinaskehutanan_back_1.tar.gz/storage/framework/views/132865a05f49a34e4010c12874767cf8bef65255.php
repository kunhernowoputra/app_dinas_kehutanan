<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>
            Data
            <small>
                <i class="ace-icon fa fa-angle-double-right"></i>
                membuat berkas data dinas kehutanan
            </small>
        </h1>
    </div>

    <div class="col-lg-4 berkas">
        <div class="widget-box widget-dark">
            <div class="widget-header widget-header-small">
                <h6 class="widget-title smaller">Form Baru</h6>
            </div>
            <div class="widget-body">
                <div class="widget-main">
                    <div class="form-group">
                        <?php echo Form::label('Tahun',null,['class'=>'control-label']); ?>

                        <input id="checkbox" type="checkbox" class="ace ace-switch ace-switch-3">
                        <span class="lbl middle"></span>
                    </div>

                    <div class="toggleDate">
                        <div class="form-group">
                            <div class="input-group">
                                <?php echo Form::text('tahun',null,['class'=>'form-control tahun','readonly'=>true]); ?>

                                <span class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                        </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo Form::button('submit',['class'=>'btn btn-success btn-mini']); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {

            $(".tahun").datepicker({
                format: " yyyy",
                autoclose: true,
                language: "id",
                viewMode: "years",
                minViewMode: "years"
            });

            $( "#checkbox" ).on( "click", function() {
                $('.toggleDate').toggle();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style>

        .toggleDate
        {
            display: none;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>