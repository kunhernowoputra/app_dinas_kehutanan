<div class="footer">
    <div class="footer-inner">
        <div class="footer-content">
                <span class="bigger-120">
                    Dinas Kehutanan &copy; kun hernowo putra 2016-2017
                </span>
            &nbsp; &nbsp;
        </div>
    </div>
</div>