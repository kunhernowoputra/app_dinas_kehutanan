<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta charset="utf-8" />
    <title>Administrator <?php echo e(Auth::user()->name); ?></title>

    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

    <!-- bootstrap & fontawesome -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/font-awesome/4.2.0/css/font-awesome.min.css')); ?>" />

    <!-- page specific plugin styles -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/datepicker.min.css')); ?>" />
    <?php echo $__env->yieldContent('css'); ?>
    <!-- text fonts -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/fonts.googleapis.com.css')); ?>" />

    <!-- ace styles -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/ace.min.css')); ?>" class="ace-main-stylesheet" id="main-ace-style" />

    <!-- inline styles related to this page -->
    <?php echo $__env->yieldContent('styles'); ?>
    <!-- ace settings handler -->
    <script src="<?php echo e(asset('assets/js/ace-extra.min.js')); ?>"></script>
</head>

<body class="no-skin">
<div id="navbar" class="navbar navbar-default">
    <script type="text/javascript">
        try{ace.settings.check('navbar' , 'fixed')}catch(e){}
    </script>

    <?php /*navigation*/ ?>
    <?php echo $__env->make('layouts.common.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<?php /*message*/ ?>
<?php echo $__env->make('layouts.common.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="main-container" id="main-container">
    <script type="text/javascript">
        try{ace.settings.check('main-container' , 'fixed')}catch(e){}
    </script>

    <?php /*sidebar*/ ?>
    <?php echo $__env->make('layouts.common.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="main-content">
        <div class="main-content-inner">

            <?php /*breadcumbs*/ ?>
            <?php echo $__env->make('layouts.common.breadcumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="page-content">
                <div class="row">
                    <div class="col-xs-12">
                        <?php /*content*/ ?>
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php /*footer*/ ?>
    <?php echo $__env->make('layouts.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
        <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
    </a>
</div>

<!-- basic scripts -->

<!--[if !IE]> -->
<script src="<?php echo e(asset('assets/js/jquery.2.1.1.min.js')); ?>"></script>
<!-- <![endif]-->

<!--[if !IE]> -->
<script type="text/javascript">
    window.jQuery || document.write("<script src='<?php echo e(asset('assets/js/jquery.min.js')); ?>'>"+"<"+"/script>");
</script>
<!-- <![endif]-->
<script type="text/javascript">
    if('ontouchstart' in document.documentElement) document.write("<script src='<?php echo e(asset('assets/js/jquery.mobile.custom.min.js')); ?>'>"+"<"+"/script>");
</script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>

<!-- page specific plugin scripts -->
<script src="<?php echo e(asset('assets/js/bootstrap-datepicker.min.js')); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>
<!-- ace scripts -->
<script src="<?php echo e(asset('assets/js/ace-elements.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/ace.min.js')); ?>"></script>
<script>
    $(function() {
        $('.date-picker').datepicker({
            format: " yyyy", // Notice the Extra space at the beginning
            viewMode: "years",
            minViewMode: "years"
        });
    });
</script>
<?php echo $__env->yieldContent('script'); ?>
<!-- inline scripts related to this page -->
</body>
</html>