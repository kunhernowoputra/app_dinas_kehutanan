<div class="widget-main widget-list">
    <?php if(count($data) > 0): ?>
        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th class="center">
                    <label class="pos-rel">
                        <input type="checkbox" class="ace" />
                        <span class="lbl"></span>
                    </label>
                </th>
                <th>Tahun</th>
                <th>Luas Wilayah Kabupaten/Kota</th>
                <th>Hutan Suaka Alam</th>
                <th>Hutan Lindung</th>
                <th>Hutan Produksi Terbatas</th>
                <th>Hutan Produksi Tetap</th>
                <th>Hutan Produksi Yang Dikonservasi</th>
                <th>Jumlah Luas Kawasan Hutan</th>
                <th>Persentase terhadap luas wilayah %</th>
                <th width="8%"></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($data as $row): ?>
                <tr>
                    <td class="center">
                        <label class="pos-rel">
                            <input type="checkbox" class="ace" />
                            <span class="lbl"></span>
                        </label>
                    </td>
                    <td><?php echo $row->tahun; ?></td>
                    <td><?php echo $row->luas; ?></td>
                    <td><?php echo $row->suaka_alam; ?></td>
                    <td><?php echo $row->lindung; ?></td>
                    <td><?php echo $row->produksi_terbatas; ?></td>
                    <td><?php echo $row->produksi_tetap; ?></td>
                    <td><?php echo $row->produksi_konservasi; ?></td>
                    <td><?php echo $row->jumlah_luas; ?></td>
                    <td><?php echo $row->persentase; ?></td>
                    <td class="text-center">

                        <?php echo Form::open(['url'=>['user/kawasan_hutan',$row->id],'method'=>'DELETE']); ?>

                        <div class="btn-group" role="group">
                            <a href="<?php echo e(url('user/kawasan_hutan/show',$row->id)); ?>" class="btn btn btn-default btn-minier">
                                <i class="icon fa fa-search"></i>
                            </a>
                            <a href="<?php echo e(url('user/kawasan_hutan/edit',$row->id)); ?>" class="btn btn btn-warning btn-minier">
                                <i class="icon fa fa-pencil"></i>
                            </a>
                            <button type="submit" class="btn btn btn-danger btn-minier">
                                <i class="icon fa fa-trash"></i>
                            </button>
                        </div>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        data tidak ditemukan
    <?php endif; ?>
</div>