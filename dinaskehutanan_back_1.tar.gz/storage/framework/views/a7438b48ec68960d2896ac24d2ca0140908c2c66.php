<?php $__env->startSection('content'); ?>
    <div class="widget-box widget-color-dark">
        <div class="widget-header widget-header-small">
            <h6 class="widget-title smaller">Luas Kawasan Hutan dan Perairan Wilayah <strong><?php echo e(Auth::user()->name); ?></strong></h6>
        </div>

        <div class="widget-body">

            <?php /*widget main update*/ ?>
            <?php echo $__env->make('user.sumber_daya_hutan.kawasan_hutan._update', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>