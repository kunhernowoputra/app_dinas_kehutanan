@extends('layouts.user')

@section('content')
    <div class="page-header">
        <h1>
            Data
            <small>
                <i class="ace-icon fa fa-angle-double-right"></i>
                membuat berkas data dinas kehutanan
            </small>
        </h1>
    </div>

    <div class="col-lg-4 berkas">
        <div class="widget-box widget-dark">
            <div class="widget-header widget-header-small">
                <h6 class="widget-title smaller">Form Baru</h6>
            </div>
            <div class="widget-body">
                <div class="widget-main">
                    <div class="form-group">
                        {!! Form::label('Tahun',null,['class'=>'control-label']) !!}
                        <input id="checkbox" type="checkbox" class="ace ace-switch ace-switch-3">
                        <span class="lbl middle"></span>
                    </div>

                    <div class="toggleDate">
                        <div class="form-group">
                            <div class="input-group">
                                {!! Form::text('tahun',null,['class'=>'form-control tahun','readonly'=>true]) !!}
                                <span class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                        </span>
                            </div>
                        </div>
                        <div class="form-group">
                            {!! Form::button('submit',['class'=>'btn btn-success btn-mini']) !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

            $(".tahun").datepicker({
                format: " yyyy",
                autoclose: true,
                language: "id",
                viewMode: "years",
                minViewMode: "years"
            });

            $( "#checkbox" ).on( "click", function() {
                $('.toggleDate').toggle();
            });
        });
    </script>
@endsection
@section('styles')
    <style>

        .toggleDate
        {
            display: none;
        }
    </style>
@endsection